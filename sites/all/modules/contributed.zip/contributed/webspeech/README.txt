This module add text-to-speech function to the website through WebSpeech.

WebSpeech is a free javascript library for web developers who want to write
pages with voice. It relies on a Web TTS server in the backend. The default one
http://wa.eguidedog.net is free for limited bandwidth usage. If you want to
have better service, please contact Cameron Wong. You can also setup the Web TTS
 server yourself. All the softwares we used are free.

Author: Cameron Wong (hgneng at yahoo.com.cn)
Website: http://www.eguidedog.net/WebSpeech.php

Please visit webspeech/demo for demos.
There is a WebSpeech block you can enable. It can help you to read main content
of the page.
