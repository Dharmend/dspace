<?php

/**
 * @file
 * Template for the FlexSlider row item
 *
 * @author Mathew Winstone (minorOffense) <mwinstone@coldfrontlabs.ca>
 */

print $item;
